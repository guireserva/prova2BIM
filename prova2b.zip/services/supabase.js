import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://ohoxftfcxzpahjtsdgma.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9ob3hmdGZjeHpwYWhqdHNkZ21hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjcwODgyMDIsImV4cCI6MjA0MjY2NDIwMn0.s_KHkLR9Pldl45WL9Y9CFNysvvUQLqDDnmCoFvZ0Y4k';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
